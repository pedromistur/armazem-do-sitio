# Armazém do Sítio

Plataforma simples para o pequeno negócio da Dona Lourdes, com catálogo de produtos e integração com WhatsApp.

## Funcionalidades

- Catálogo de produtos
- Simulação de carrinho de compras
- Envio do pedido direto para o WhatsApp da loja

## Tecnologias

- HTML, CSS, JavaScript
- Integração com WhatsApp
- Layout responsivo

## Como usar

1. Baixe ou clone este repositório
2. Edite o número de WhatsApp em `script.js` na função `finalizarPedido`
3. Abra `index.html` em um navegador

## Feito para: Projeto Integrador com Empresa – Curso de TI