const produtos = [
  { nome: "Geleia de Morango", preco: 15, imagem: "https://via.placeholder.com/200?text=Geleia" },
  { nome: "Queijo Artesanal", preco: 30, imagem: "https://via.placeholder.com/200?text=Queijo" },
  { nome: "Tomate Orgânico", preco: 6, imagem: "https://via.placeholder.com/200?text=Tomate" }
];

let carrinho = [];

function carregarProdutos() {
  const container = document.getElementById("produtos");
  produtos.forEach((produto, index) => {
    const card = document.createElement("div");
    card.className = "produto";
    card.innerHTML = `
      <img src="${produto.imagem}" alt="${produto.nome}">
      <h3>${produto.nome}</h3>
      <p>R$ ${produto.preco},00</p>
      <button onclick="adicionarAoCarrinho(${index})">Adicionar</button>
    `;
    container.appendChild(card);
  });
}

function adicionarAoCarrinho(index) {
  carrinho.push(produtos[index]);
  alert(`${produtos[index].nome} adicionado ao carrinho!`);
}

function finalizarPedido() {
  if (carrinho.length === 0) {
    alert("Seu carrinho está vazio!");
    return;
  }

  let mensagem = "Olá, Dona Lourdes! Quero fazer um pedido:\n";
  let total = 0;

  carrinho.forEach((item) => {
    mensagem += `• ${item.nome} - R$ ${item.preco},00\n`;
    total += item.preco;
  });

  mensagem += `Total: R$ ${total},00`;

  const whatsappLink = `https://wa.me/55SEUNUMEROAQUI?text=${encodeURIComponent(mensagem)}`;
  window.open(whatsappLink, "_blank");
}

window.onload = carregarProdutos;